-- MySQL dump 10.13  Distrib 8.0.23, for Linux (x86_64)
--
-- Host: election.cpawyehotia9.ap-south-1.rds.amazonaws.com    Database: Election
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `Constituency`
--

DROP TABLE IF EXISTS `Constituency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Constituency` (
  `id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `region` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Constituency`
--

LOCK TABLES `Constituency` WRITE;
/*!40000 ALTER TABLE `Constituency` DISABLE KEYS */;
INSERT INTO `Constituency` VALUES (1,'Nerela','North Delhi'),(2,'Burari','Central Delhi'),(3,'Timarpur','Central Delhi'),(4,'Adarsh Nagar','North Delhi'),(5,'Badli','North Delhi'),(6,'Rithala','North West Delhi'),(7,'Bawana','North Delhi'),(8,'Mundka','North West Delhi'),(9,'Kirari','North West Delhi'),(10,'Sultanpur Majra','North West Delhi'),(11,'Nangloi Jat','West Delhi'),(12,'Mangol Puri','North West Delhi'),(13,'Rohini','North Delhi'),(14,'Shalimar Bagh','North West Delhi'),(15,'Shakur Basti','North Delhi'),(16,'Tri Nagar','North West Delhi'),(17,'Wazirpur','North Delhi'),(18,'Model Town','North Delhi'),(19,'Sadar Bazar','Central Delhi'),(20,'Chandni Chowk','Central Delhi'),(21,'Matia Mahal','Central Delhi'),(22,'Ballimaran','Central Delhi'),(23,'Karol Bagh','Central Delhi'),(24,'Patel Nagar','New Delhi'),(25,'Moti Nagar','West Delhi'),(26,'Madipur','West Delhi'),(27,'Rajouri Garden','West Delhi'),(28,'Hari Nagar','West Delhi'),(29,'Tilak Nagar','West Delhi'),(30,'Janakpuri','West Delhi'),(31,'Vikaspuri','South West Delhi'),(32,'Uttam Nagar','South West Delhi'),(33,'Dwarka','South West Delhi'),(34,'Matiala','South West Delhi'),(35,'Najafgarh','South West Delhi'),(36,'Bijwasan','South West Delhi'),(37,'Palam','South West Delhi'),(38,'Delhi Cantonment','New Delhi'),(39,'Rajinder Nagar','New Delhi'),(40,'New Delhi','New Delhi'),(41,'Jangpura','South East Delhi'),(42,'Kasturba Nagar','South East Delhi'),(43,'Malviya Nagar','South Delhi'),(44,'R K Puram','New Delhi'),(45,'Mehrauli','South Delhi'),(46,'Chhatarpur','South Delhi'),(47,'Deoli','South Delhi'),(48,'Ambedkar Nagar','South Delhi'),(49,'Sangam Vihar','South East Delhi'),(50,'Greater Kailash','New Delhi'),(51,'Kalkaji','South East Delhi'),(52,'Tughlkabad','South East Delhi'),(53,'Badarpur','South East Delhi'),(54,'Okhla','South East Delhi'),(55,'Trilokpuri','East Delhi'),(56,'Kondli','East Delhi'),(57,'Patparganj','East Delhi'),(58,'Laxmi Nagar','East Delhi'),(59,'Vishwas Nagar','Shahdara'),(60,'Krishna Nagar','East Delhi'),(61,'Gandhi Nagar','East Delhi'),(62,'Shahdara','Shahdara'),(63,'Seemapuri','Shahdara'),(64,'Rohtas Nagar','Shahdara'),(65,'Seelampur','North East Delhi'),(66,'Ghonda','North East Delhi'),(67,'Babarpur','Shahdara'),(68,'Gokalpur','North East Delhi'),(69,'Mustafabad','North East Delhi'),(70,'Karawal Nagar','North East Delhi');
/*!40000 ALTER TABLE `Constituency` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-15  6:43:19
