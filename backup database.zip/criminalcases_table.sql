-- MySQL dump 10.13  Distrib 8.0.23, for Linux (x86_64)
--
-- Host: election.cpawyehotia9.ap-south-1.rds.amazonaws.com    Database: Election
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `candidate_criminal_cases`
--

DROP TABLE IF EXISTS `candidate_criminal_cases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `candidate_criminal_cases` (
  `criminal_id` int NOT NULL,
  `biodata_id` int NOT NULL,
  `biodata_year` year NOT NULL,
  `criminal_case` varchar(30) NOT NULL,
  PRIMARY KEY (`criminal_id`),
  KEY `biodata_id` (`biodata_id`),
  CONSTRAINT `candidate_criminal_cases_ibfk_1` FOREIGN KEY (`biodata_id`) REFERENCES `BioData` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `candidate_criminal_cases`
--

LOCK TABLES `candidate_criminal_cases` WRITE;
/*!40000 ALTER TABLE `candidate_criminal_cases` DISABLE KEYS */;
INSERT INTO `candidate_criminal_cases` VALUES (1,246,2008,'Murder'),(2,240,2008,'Culpable Homicide not amountin'),(3,404,2020,'Hit and Run'),(4,367,2015,'Abetment of Suicide'),(5,223,2008,'Attempt to Commit Murder'),(6,400,2020,'Attempt to commit Culpable Hom'),(7,368,2015,'Attempt to Commit Suicide'),(8,379,2015,'Infanticide '),(9,245,2008,'Foeticide'),(10,66,2021,'Abandonment'),(11,445,2020,'Voluntarily Causing Simple Hur'),(12,420,2020,'Rioting'),(13,245,2008,'Kidnapping for Ransom'),(14,211,2013,'Causing Hurt by act endangerin'),(15,75,2021,'Voluntarily causing grievous h'),(16,67,2021,'Acid Attack'),(17,215,2008,'Attempt to Acid Attack'),(18,253,2008,'Wrongful Restraint/Confinement'),(19,253,2008,'Rioting'),(20,331,2013,'Sexual Harassment at Work Prem'),(21,366,2015,' Exploitation of Trafficked Pe'),(22,419,2020,'Kidnapping for the Purpose of '),(23,328,2013,'Kidnapping in order to Murder'),(24,415,2020,'Kidnapping for Ransom'),(25,378,2015,'Human Trafficking'),(26,68,2021,'Attempt to Commit Rape'),(27,383,2015,'Sedition'),(28,75,2021,'Rioting'),(29,411,2020,'Electricity/Power Supply Dispu'),(30,380,2015,'Rioting/Attacks on Police Pers'),(31,329,2013,'Promoting enmity between group'),(32,69,2021,'Auto/Motor Vehicle Theft'),(33,412,2020,'Extortion & Blackmailing'),(34,376,2015,'Dacoity'),(35,232,2008,'Counterfeiting Government Stam'),(36,377,2015,'Forgery, Cheating & Fraud'),(37,329,2013,'Rash Driving on Public way'),(38,75,2021,'Offences relating to Religion'),(39,71,2021,'Cruelty by Husband or his Rela'),(40,245,2008,'Illegal/Unlicensed Arms'),(41,250,2008,'Possession of drugs for Person'),(42,250,2008,'Possession of drugs for Traffi'),(43,224,2008,'Cheating by Impersonation'),(44,70,2021,'Circulate False/Fake News/Rumo'),(45,74,2021,'Insult to the Modesty of Women'),(46,250,2008,'Promoting enmity between group'),(47,404,2020,'Auto/Motor Vehicle Theft'),(48,73,2021,'Extortion & Blackmailing'),(49,72,2021,'Dacoity'),(50,325,2013,'Counterfeiting Government Stam');
/*!40000 ALTER TABLE `candidate_criminal_cases` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-15  6:46:10
